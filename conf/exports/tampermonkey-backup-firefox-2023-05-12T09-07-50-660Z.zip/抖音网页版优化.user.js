// ==UserScript==
// @name 抖音网页版优化
// @description 抖音网页版推荐、直播优化，网页全屏，全黑，自动按浏览器窗口调整大小
// @namespace https://space.bilibili.com/482343
// @author 古海沉舟
// @license 古海沉舟
// @version 1.9.2
// @match https://www.douyin.com/*
// @include https://www.douyin.com/recommend
// @include https://www.douyin.com/*
// @include https://www.douyin.com/?*
// @include https://www.douyin.com/follow
// @include https://live.douyin.com/*
// @require https://cdn.staticfile.org/jquery/1.12.4/jquery.min.js
// @run-at document-end
// @grant GM_setValue
// @grant GM_getValue
// @grant GM_addValueChangeListener
// @noframes
// ==/UserScript==

var lastindex=0,livecount=0,livewidth=0,onelinecount,livelinecount,hovercount;

function keydown(event) {
    //console.log(event.keyCode);
    if(event.keyCode == 109 || event.keyCode == 189){ // 按-或者小键盘-
        pagefullscreen();
    }
}
document.addEventListener('keydown', keydown, false);

var haspagefullscreen=0;
if (location.href.indexOf("https://www.douyin.com/follow")>-1){
    haspagefullscreen=1;

    let livestyle = document.createElement('style');
    livestyle.classList.add("live");
    livestyle.innerHTML = `
        .NQ38Bc0h .nvzm0QdP .X5RsU67Q { display: flex; flex-wrap: wrap; flex: 1 1 auto; overflow-y: scroll; }
div.X5RsU67Q { width: 100%; overflow: auto; margin: auto; }
div.X5RsU67Q { left: 0 !important; right: 0 !important; bottom: 0 !important; top: 0 !important; position: absolute !important; margin: auto !important; transform: none !important; }
.NQ38Bc0h{height:100%}
.JTIGfG2P.aSKksRfh { display: flex; flex-wrap: wrap; flex: 6 1 auto; overflow-y: scroll; height: auto !important; max-height: 550px !important; }
.YwClj8rK:hover{
    flex: 12 1;
}
.YwClj8rK { min-height: 20px !important; }
.NQ38Bc0h .nvzm0QdP .X5RsU67Q .o3pEYU7M { height: 80px !important; margin-left: 5px !important; margin-right: 5px !important; }
.Jt6LO5RK .qOwBZHet .trexWhDY { border-radius: 0%; height: 48px; width: 48px; }
.Jt6LO5RK .qOwBZHet .trexWhDY { animation: none; }
.Jt6LO5RK .qOwBZHet { margin-top: 13px; margin-bottom: 2px; }
.Jt6LO5RK .qOwBZHet .y5X4PaKT, .Jt6LO5RK .qOwBZHet .o4w20gFP, div.XcEg0PrM,div.Lo8QPz5R{ display: none !important }

.lXuWkeYW, .lXuWkeYW .oJArD0aS {
    height: 60px !important;
}

div[data-e2e="recommend-guide-mask"]{display: none!important}
`
    document.body.appendChild(livestyle);
    var liveheight=setInterval(function(){
         //直播个数
        livecount=$(`#douyin-right-container > div.JTIGfG2P.aSKksRfh > div > div.nvzm0QdP > div.X5RsU67Q > a`).length;
        console.log("直播个数",livecount);
        //宽度
        livewidth=$(`#douyin-right-container > div.JTIGfG2P.aSKksRfh > div > div.nvzm0QdP > div.X5RsU67Q`).width();
        console.log("宽度",livewidth);
        //每行多少列
        onelinecount=Math.trunc(livewidth/90);
        console.log("每行多少列",onelinecount);
        //多少行
        livelinecount=Math.ceil(livecount/onelinecount);
        console.log("多少行",livelinecount);
        //显示部分多高
        livecount=$(`#douyin-right-container`).height()-60;
        console.log("显示部分多高",livecount);
        //最大比例
        livewidth=Math.trunc(livecount/80)-1;
        console.log("最大比例",livewidth);
        //当前数量比例
        onelinecount=(livelinecount*80)/(livecount-(livelinecount*80))
        console.log("全部显示比例",onelinecount);
        //应该显示比例
        if( onelinecount<0) {
            livelinecount=livewidth;
        }else{
        livelinecount=Math.min(livewidth,onelinecount);
        }
        console.log("应该显示比例",livelinecount);
        //悬停显示比例
        hovercount=(livecount/80-1)*livelinecount;
        console.log("悬停显示比例",hovercount);

    if (isNaN(livelinecount) || livelinecount==null){
        return
    }
        clearInterval(liveheight);
        let livestyle2 = document.createElement('style');
        livestyle2.classList.add("live2");
        livestyle2.innerHTML = `
.JTIGfG2P.aSKksRfh { display: flex; flex-wrap: wrap; flex: `+livelinecount+` 1 auto; overflow-y: scroll; height: auto !important; max-height: 550px !important; }
.YwClj8rK:hover{ flex: `+hovercount +` 1;
}
`
    document.body.appendChild(livestyle2);
    },500);

}
function pagefullscreen(){
    var is=0;
    //$(`#slidelist > div > div.swiper-wrapper > div.swiper-slide-active xg-icon.xgplayer-page-full-screen > div.xgplayer-icon`).click();
    $(`#sliderVideo xg-icon.xgplayer-page-full-screen > div.xgplayer-icon`).each(function(){
        haspagefullscreen=1;
        $(this).click();
        is=1;
        if (is){return}
        console.log("非推荐");
        $(`xg-controls xg-icon>div > div:nth-child(2)`).each(function(){
            if ($(this).parent().text().indexOf("网页全屏")<0)return;
            console.log("判断：",$(this).text(),"  ",$(this)[0]);
            haspagefullscreen=1;
            $(this).click();
        })
    })
    if (is){return}
    $(`div[data-e2e="living-container"] xg-icon>div>div`).each(function(){
        if ($(this).parent().text().indexOf("网页全屏")<0)return;
        console.log("判断：",$(this).text(),"  ",$(this)[0]);
        haspagefullscreen=1;
        $(this).click();
    })

}
var firstfullscreen=setInterval(function(){
    if (haspagefullscreen){
        clearInterval(firstfullscreen);
        return;
    }
    pagefullscreen();
},1000);

setInterval(function(){
    filtergift();
},1000);

function filtergift(){ //过滤直播礼物
    $(`div.webcast-chatroom___item span.Q7mln_nz`).each(function(){
        if ($(this).text().indexOf("送出了")>-1){
            console.log($(this).parent().parent().parent().parent().text().replace(/\n/g, " ").replace(/\s\s/g, " "));
            $(this).parent().parent().parent().parent().hide();
        }
    })
}
function addCSS(){
    let wdstyle = document.createElement('style');
    wdstyle.classList.add("optimize");
    wdstyle.innerHTML = `
div.gNyVUu_s, .OaNxZqFU img, .iRX47Q8q img { display: none!important }
.qdcce5kG .VFMR0HAe { background: #0000 !important }
.vLt8mbfQ .y8iJbHin .mMOxHVzv, .vLt8mbfQ .y8iJbHin .rrKCA47Q, div.webcast-chatroom, .BasEuG5Q ._QjzkgP3, .OaNxZqFU,.basicPlayer.xgplayer{ background: #000 !important }
.Npz7CPXj, div.webcast-chatroom .webcast-chatroom___input-container .webcast-chatroom___textarea, .CgAB9miy, .JTIGfG2P, .NQ38Bc0h .XcEg0PrM, .N_HNXA04:not(.dUiu6B8O) .iViO9oMI, .UKFpY5tW, .SxCiQ8ip .EDvjMGPs,.SxCiQ8ip .A0ewbQCI,.fpRIB_wC,div.tgMCqIjJ, div.tgMCqIjJ.isDark,.sELpHy0M.metro .lgs6xhy7 .slot-item:hover,.sELpHy0M.metro .B9p3ney8:hover,.sELpHy0M.metro .UjStUCgW ._BSUxMOF:hover{ background: #111 !important }
.N_HNXA04:not(.dUiu6B8O) .kQ2JnIMK .n9PPTk22, .N_HNXA04 .kQ2JnIMK, .iwzpXgQ3 .oJArD0aS, .xWPMYXKp .gOSlkVoB, .Exz5X5r1,.R5ITbXfy .k5cuEeRD,.sELpHy0M.metro .lgs6xhy7 .slot-item,.sELpHy0M.metro .B9p3ney8,.sELpHy0M.metro .UjStUCgW ._BSUxMOF{ background: #222 !important }
div.JwGiJkkI, div.xgplayer-dynamic-bg, div.umOY7cDY, div.ruqvqPsH { display: none !important }
.L8o4Hyg1,.L8o4Hyg1 .LFbb1oon,.L8o4Hyg1 .R6NHkCAw .i4vdvOF5{ box-shadow: none !important; border-bottom: none !important; border-right: none !important; }

.pgQgzInF.hqONwptG .Jf1GlewW.Ox89VrU5, .ckEyweZa.AmXnh1GR .QICHGW7r.RosH2lNv, .SxCiQ8ip.V6Va18Np .EDvjMGPs.FKQqfehj { height: 100% !important; }
div.immersive-player-switch-on-hide-interaction-area, #video-info-wrap, xg-inner-controls.xg-inner-controls { opacity: 0.6 !important }
.xgplayer-playswitch .xgplayer-playswitch-tab { opacity: 0 !important }
div.xgplayer-playswitch-tab:hover, div.immersive-player-switch-on-hide-interaction-area:hover, #video-info-wrap:hover, xg-inner-controls.xg-inner-controls:hover { opacity: 1 !important }
`
    document.body.appendChild(wdstyle);
}
addCSS();